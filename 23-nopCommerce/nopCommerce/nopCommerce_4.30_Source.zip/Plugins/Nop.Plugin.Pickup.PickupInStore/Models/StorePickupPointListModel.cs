﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Pickup.PickupInStore.Models
{
    public partial class StorePickupPointListModel : BasePagedListModel<StorePickupPointModel>
    {
    }
}
