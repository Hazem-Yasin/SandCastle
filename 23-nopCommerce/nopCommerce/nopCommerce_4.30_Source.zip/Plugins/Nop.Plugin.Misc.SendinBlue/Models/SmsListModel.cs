﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.SendinBlue.Models
{
    /// <summary>
    /// Represents SMS list model
    /// </summary>
    public class SmsListModel : BasePagedListModel<SmsModel>
    {
    }
}