﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Tax.FixedOrByCountryStateZip.Models
{
    public partial class CountryStateZipListModel : BasePagedListModel<CountryStateZipModel>
    {
    }
}