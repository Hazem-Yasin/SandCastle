﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Widgets.FacebookPixel.Models
{
    /// <summary>
    /// Represents a custom event list model
    /// </summary>
    public class CustomEventListModel : BasePagedListModel<CustomEventModel>
    {
    }
}